import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by VcamX on 12/5/14.
 */
public class LogAnalyzer {

    public static class Log {

        public String clientIp;
        public String rfcId;
        public String uid;
        public String time;
        public String timeZone;
        public String httpMethod;
        public String httpRequest;
        public String httpProtocol;
        public int statusCode;
        public int dataSize;

        private Calendar calendar = Calendar.getInstance();

        public static Log newInstance(String line) {
            String chunks[] = line.split(" ");

            Log log = new Log();

            log.clientIp = chunks[0];
            log.rfcId = chunks[1];
            log.uid = chunks[2];

            log.time = chunks[3].substring(1);
            log.timeZone = chunks[4].substring(0, chunks[4].length()-1);

            log.httpMethod = chunks[5].substring(1);

            StringBuilder sb = new StringBuilder(chunks[6]);
            for (int i=7; i<chunks.length-3; ++i) {
                sb.append(" " + chunks[i]);
            }
            log.httpRequest = sb.toString();

            log.httpProtocol = chunks[chunks.length-3].substring(0, chunks[chunks.length-3].length()-1);

            log.statusCode = Integer.valueOf(chunks[chunks.length-2]);
            log.dataSize = chunks[chunks.length-1].equals("-") ? 0 : Integer.valueOf(chunks[chunks.length-1]);

            log.initTime();

            return log;
        }

        private Log() {}

        public String toString() {
            return "Log(ip=" + clientIp
                    + ", rfc=" + rfcId
                    + ", uid=" + uid
                    + ", time=" + time
                    + ", timezone=" + timeZone
                    + ", http=" + httpMethod
                    + ", content=" + httpRequest
                    + ", protocol=" + httpProtocol
                    + ", status=" + statusCode
                    + ", size=" + dataSize + ")";

        }

        public boolean isBroken() {
            return statusCode == 404;
        }

        public void initTime() {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss");
            try {
//                System.out.println(time);
                Date date = sdf.parse(time);
                calendar.setTime(date);
            }
            catch (ParseException e) {
                e.printStackTrace();
            }
        }

        public int time_hour() {
            return calendar.get(Calendar.HOUR_OF_DAY);
        }

        public int time_wday() {
            return calendar.get(Calendar.DAY_OF_WEEK);
        }

        public int time_mday() {
            return calendar.get(Calendar.DAY_OF_MONTH);
        }
    }

    private List<Log> logs = new ArrayList<Log>();

    public void addLog(String line) {
//        System.out.println(line);
        logs.add(Log.newInstance(line));
    }

    public void showMostPopularPage() {
        Map<String, Set<Log>> pageToLog = new HashMap<String, Set<Log>>();

        for (Log log : logs) {
            Set<Log> logSet;
            if (pageToLog.containsKey(log.httpRequest)) {
                logSet = pageToLog.get(log.httpRequest);
            }
            else {
                logSet = new HashSet<Log>();
                pageToLog.put(log.httpRequest, logSet);
            }

            logSet.add(log);
        }

        String maxVisitPage = "None";
        int maxVisitCount = -1;

        for (String key : pageToLog.keySet()) {
            Set<Log> logSet = pageToLog.get(key);
            if (logSet.size() > maxVisitCount) {
                maxVisitCount = logSet.size();
                maxVisitPage = key;
            }
        }

        System.out.println("Most popular page: " + maxVisitPage);
        System.out.println("Access count: " + maxVisitCount);
        System.out.println();
    }

    public void showMostAccess() {
        Map<String, Set<String>> ipToPagesMap = new HashMap<String, Set<String>>();

        for (Log log : logs) {
            if (!log.isBroken()) {
                Set<String> pageSet;
                if (ipToPagesMap.containsKey(log.clientIp)) {
                    pageSet = ipToPagesMap.get(log.clientIp);
                }
                else {
                    pageSet = new HashSet<String>();
                    ipToPagesMap.put(log.clientIp, pageSet);
                }

                pageSet.add(log.httpRequest);
            }
        }

        String clientIp = "None";
        int pageCount = -1;
        for (String key : ipToPagesMap.keySet()) {
            if (pageCount < ipToPagesMap.get(key).size()) {
                clientIp = key;
                pageCount = ipToPagesMap.get(key).size();
            }
        }

        System.out.println("IP of client which accessed most pages of site: " + clientIp);
        System.out.println();
    }

    public void showBrokenLinks(boolean flag) {
        Set<String> brokenLinks = new HashSet<String>();

        for (Log log : logs) {
            if (log.isBroken() && !brokenLinks.contains(log.httpRequest)) {
                brokenLinks.add(log.httpRequest);
            }
        }

        if (brokenLinks.size() > 0) {
            System.out.println("Other sites appear to have broken links to this site’s pages");
            if (flag) {
                System.out.println("Broken links:");
                for (String link : brokenLinks) {
                    System.out.println("\t" + link);
                }
            }
        }
        else {
            System.out.println("Other sites have no broken links to this site’s pages");
        }
        System.out.println();
    }

    public void showTotalDataTransfer() {
        long dataSize = 0;
        for (Log log : logs) {
            dataSize += log.dataSize;
        }

        System.out.println("Total data transfer: " + dataSize + " byte(s)");
        System.out.println();
    }

    public void showBusiestPeriod() {
        Map<Integer, Integer> dayInfo = new HashMap<Integer, Integer>();
        Map<Integer, Integer> weekInfo = new HashMap<Integer, Integer>();
        Map<Integer, Integer> monthInfo = new HashMap<Integer, Integer>();

        for (Log log : logs) {
            int hour = log.time_hour();
            if (dayInfo.containsKey(hour)) {
                dayInfo.put(hour, dayInfo.get(hour) + 1);
            }
            else {
                dayInfo.put(hour, 1);
            }

            int wday = log.time_wday();
            if (weekInfo.containsKey(wday)) {
                weekInfo.put(wday, weekInfo.get(wday) + 1);
            }
            else {
                weekInfo.put(wday, 1);
            }

            int mday = log.time_mday();
            if (monthInfo.containsKey(mday)) {
                monthInfo.put(mday, monthInfo.get(mday) + 1);
            }
            else {
                monthInfo.put(mday, 1);
            }
        }

        int busiestHour = -1;
        int accessHourCount = -1;
        for (int h : dayInfo.keySet()) {
            if (accessHourCount < dayInfo.get(h)) {
                busiestHour = h;
                accessHourCount = dayInfo.get(h);
            }
        }
        System.out.println("The busiest period (hour) of day: "+busiestHour);


        int busiestWeekDay = -1;
        int accessWeekDayCount = -1;
        for (int d : weekInfo.keySet()) {
            if (accessWeekDayCount < weekInfo.get(d)) {
                busiestWeekDay = d;
                accessWeekDayCount = weekInfo.get(d);
            }
        }
        String weekDay;
        switch (busiestWeekDay) {
            case(1) : weekDay = "Sunday"; break;
            case(2) : weekDay = "Monday"; break;
            case(3) : weekDay = "Tuesday"; break;
            case(4) : weekDay = "Wednesday"; break;
            case(5) : weekDay = "Thursday"; break;
            case(6) : weekDay = "Friday"; break;
            case(7) : weekDay = "Saturday"; break;
            default:
                weekDay = "Unknown";
        }
        System.out.println("The busiest period of week: "+weekDay);


        int busiestMonthDay = -1;
        int accessMonthDayCount = -1;
        for (int d : monthInfo.keySet()) {
            if (accessMonthDayCount < monthInfo.get(d)) {
                busiestMonthDay = d;
                accessMonthDayCount = monthInfo.get(d);
            }
        }
        System.out.println("The busiest period (day) of month: "+busiestMonthDay);

        System.out.println();
    }

    public static void usage() {
        System.out.println("usage: LogAnalyzer [OPTION] FILENAME");
        System.out.println("\nOPTION:");
        System.out.println("\t-h: Show this message");
    }

    public static void main(String args[]) {
////        String line = "::1 - - [18/Mar/2012:17:39:14 +0800] \"GET / HTTP/1.0\" 200 3239";
//        String line = "125.73.81.255 - - [19/Mar/2012:07:14:27 +0800] \"GET http://www.google.com/ HTTP/1.0\" 200 3239";
//
//        Log log = Log.newInstance(line);
//        System.out.println(log);
//        System.out.println(log.time_hour());
//        System.out.println(log.time_wday());
//        System.out.println(log.time_mday());

        if (args.length < 1) {
            usage();
            return;
        }

        if (args[0].equals("-h")) {
            usage();
        }
        else {
            LogAnalyzer logAnalyzer = new LogAnalyzer();
            try {
                FileReader fr = new FileReader(args[0]);
                BufferedReader br = new BufferedReader(fr);

                String line = br.readLine();
                while (line != null) {
                    logAnalyzer.addLog(line);

                    line = br.readLine();
                }

                br.close();
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }

            logAnalyzer.showMostPopularPage();
            logAnalyzer.showMostAccess();
            logAnalyzer.showBrokenLinks(false);
            logAnalyzer.showTotalDataTransfer();
            logAnalyzer.showBusiestPeriod();
        }
    }
}
