package com.cnnblike.Assignment004;
//Log Analyzer
//To view the exact requirement of this assignment,visit http://fm.zju.edu.cn/showProblem.php?cid=89&pid=932
import java.util.*;
import java.io.*;

    public class Main {

        public static void main(String[] args) throws Exception {
            int totalRecords = 0;//the total access count in the record
            int index;
            int[] PagesToken;//count page number that every ip visit
            PagesToken = new int[1000000];
            int MaxPagesToken = 0;//most visited page
            int[] PopularPage;
            PopularPage = new int[100000];//the count number of every page
            int MostPopularPage = 0;//most popular page
            int temp = 0;
            int temp1 = 0;
            String File_Path= "access.log";
            //the default file path is the access.log on my computer so if the args.length==0
            //then the program should visit the default path
            if (args.length!=0){
                File_Path= args[1];
            }
            BufferedReader bf = new BufferedReader(new FileReader(File_Path));
            String line;
            LinkedList ipList = new LinkedList();//save different ip address
            LinkedList pageList = new LinkedList();//save different page
            line = bf.readLine();
            while (line != null) {
                Access as = new Access(line);
                //deal with ip
                if (!ipList.contains(as.Host)) {
                    ipList.addLast(as.Host);
                }
                //count Page Token
                else {
                    index = ipList.indexOf(as.Host);
                    PagesToken[index]++;
                }
                //Done.
                //Deal with web page URL
                if (!pageList.contains(as.URL))
                    pageList.addLast(as.URL);
                else {
                    index = pageList.indexOf(as.URL);
                    PopularPage[index]++;
                }
                line = bf.readLine();

            }
            int i = 0;

            //find the most popular page
            for (i = 0; i < PopularPage.length; i++) {
                if (PopularPage[i] > MostPopularPage) {
                    MostPopularPage = PopularPage[i];
                    temp1 = i;
                }
            }
            //output the result of the log analyzer
            System.out.println("The most popular page is " + pageList.get(temp1));
            System.out.println("visited " + MostPopularPage + " times");
            //find the most visiting IP
            for (i = 0; i < PagesToken.length; i++) {

                if (PagesToken[i] > MaxPagesToken) {
                    MaxPagesToken = PagesToken[i];
                    temp = i;
                }

            }
            System.out.println("The ip who visit the most pages are " + ipList.get(temp));
            System.out.println(MaxPagesToken + " times");

        }
    }


