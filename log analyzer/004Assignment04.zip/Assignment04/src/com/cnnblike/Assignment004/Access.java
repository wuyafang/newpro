package com.cnnblike.Assignment004;
import java.util.StringTokenizer;
/**
 * Created by cnnblike_Mac on 14/12/14.
 */
public class Access {
    String Host;// the address the of server.
    String Time;// the time of visiting
    String Request;// request way of visiting
    String Method;// the method of accessing
    String URL;// the url of the visited page
    int status;// status
    int size = 0;// size of the package

    public Access(String Data) {
        StringTokenizer Splitter = new StringTokenizer(Data, " \t");
        String skip;
        //Sample line to the file should be like the following:
        //127.0.0.1 - - [03/Sep/2012:13:53:07 +0800] "GET / HTTP/1.1" 200 44
        Host = Splitter.nextToken();//127.0.0.1
        skip = Splitter.nextToken();//-
        skip = Splitter.nextToken("[");// - [
        Time = Splitter.nextToken(" \t");//03/Sep/2012:13:53:07 +0800
        skip = Splitter.nextToken("\"");//] "
        Request = Splitter.nextToken();//GET / HTTP/1.1
        skip = Splitter.nextToken(" \t");//"
        status = Integer.parseInt(Splitter.nextToken(" \t"));
        try {
            size = Integer.parseInt(Splitter.nextToken(" \t"));
        } catch (Exception e) {
            size = 0;
        }
        Splitter = new StringTokenizer(Request);
        Method = Splitter.nextToken();
        if (Splitter.hasMoreTokens()) {
            URL = Splitter.nextToken();
        }
    }
}
