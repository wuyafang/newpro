package tryjframe;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;

class RectShape implements Serializable   
{   
	private Rectangle2D rect;   
	private Color c;   
  
	public RectShape()   
	{   
		rect=null;   
		c=Color.BLACK;   
	}   
  
	public RectShape(Rectangle2D rect,Color c)   
	{   
		this.rect=rect;   
		this.c=c;   
	}   
	  
	public Rectangle2D getRect() {return rect;}   
	public Color getColor() {return c;}   
	public void setRect(Rectangle2D rect) {this.rect=rect;}   
	public void setColor(Color c) {this.c=c;}   
} 
