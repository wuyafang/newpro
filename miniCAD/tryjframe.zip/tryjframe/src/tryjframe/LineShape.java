package tryjframe;

import java.awt.Color;
import java.awt.geom.Line2D;
import java.io.Serializable;

class LineShape implements Serializable   
{   
	static Line2D line;   
	private Color c;   
  
	public LineShape()   
	{   
		line=null;   
		c=Color.BLACK;   
	}   
  
	public LineShape(Line2D line,Color c)   
	{   
		this.line=line;   
		this.c=c;   
	}   
  
	public Line2D getLine() {return line;}   
	public Color getColor() {return c;}   
	public void setLine(Line2D line) {this.line=line;}   
	public void setColor(Color c) {this.c=c;}   
}   
  