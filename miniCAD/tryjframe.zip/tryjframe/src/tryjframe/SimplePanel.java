package tryjframe;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import javax.swing.JPanel;

//panel class   
	class SimplePanel extends JPanel   
	{   
		static ArrayList<LineShape> line;   
		static ArrayList<RectShape> rect;   
		static ArrayList<ElliShape> elli;   
		  
		private Point2D begin=null;   
		private Point2D end=null;   
		  
		private static int vernier=0;   
		private static int[] a=new int[100];   
	  
		public SimplePanel()   
		{   
			System.out.println("SimplePanel ok!");
			line=new ArrayList<LineShape>();   
			rect=new ArrayList<RectShape>();   
			elli=new ArrayList<ElliShape>();   
			
			for(int m=0;m<100;m++)   
			a[m]=0;   
			  
//			addMouseListener(new MouseAction());   
//			addMouseMotionListener(new MouseMotionAction());   
		}   
	  
		public void paintComponent(Graphics2D g)   
		{   
			super.paintComponent(g);   
			Graphics2D g2=g;   
			  
			for(LineShape l:line)   
			{   
				g2.setPaint(l.getColor());   
				g2.draw(l.getLine());   
			}   
	  
	  
			for(RectShape r:rect)   
			{   
				g2.setPaint(r.getColor());   
				g2.draw(r.getRect());   
			}   
		  
	  
			for(ElliShape e:elli)   
			{   
				g2.setPaint(e.getColor());   
				g2.draw(e.getElli());   
			}   
		  
		} 
	}