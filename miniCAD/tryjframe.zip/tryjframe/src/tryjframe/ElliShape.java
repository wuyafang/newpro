package tryjframe;

import java.awt.Color;
import java.awt.geom.Ellipse2D;
import java.io.Serializable;

class ElliShape implements Serializable   
{   
	private Ellipse2D elli;   
	private Color c;   
	  
	public ElliShape()   
	{   
		elli=null;   
		c=Color.BLACK;   
	}   
	  
	public ElliShape(Ellipse2D elli,Color c)   
	{   
		this.elli=elli;   
		this.c=c;   
	}   
  
	public Ellipse2D getElli() {return elli;}   
	public Color getColor() {return c;}   
	public void setElli(Ellipse2D elli) {this.elli=elli;}   
	public void setColor(Color c) {this.c=c;}   
}   
