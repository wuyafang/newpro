package tryjframe;


import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.awt.*;   
import java.awt.event.*;   

import javax.swing.*;   

import java.net.*;   
import java.io.*;  
public class Menuaction {
	//�½���ͼ
//	public void xinjian()
//	{
//		System.out.println("xinjian ok!");
//		//��������
//		SimplePanel panel=new SimplePanel();
//		panel.setBackground(Color.white);
//		frame.add(panel);  
//		panel.addMouseListener(this); 
//	}
	//��ͼƬ
	public void open()
	{
//		JFileChooser chooser=new JFileChooser();
//		Tryframe.dir=".";
//		int chooseResult=chooser.showOpenDialog(Tryframe.frame);   
//		  
//		if(chooseResult==JFileChooser.APPROVE_OPTION)   
//		{   
//			try   
//			{   
//				Tryframe.dir=chooser.getSelectedFile().getPath();   
//				ObjectInputStream in=new ObjectInputStream(new FileInputStream(Tryframe.dir));   
//				read(in);   
//				in.close();   
//			}   
//			catch(IOException e) {}   
//			catch(ClassNotFoundException n) {}   
//		}   
//		paint();   
//		System.out.println("open ok!");
//		JFileChooser jf=new JFileChooser(); 
//		Tryframe.frame.setVisible(true);
//		int n=jf.showOpenDialog(Tryframe.frame);   
//			 
//			 
//		try{   
//			if(n==JFileChooser.APPROVE_OPTION){   
//				File f=jf.getSelectedFile(); 
////				Tryframe.g.drawLine(1,1,0,0);
////				update(g); 
//				open(f);
//			}   
//		}catch(Exception e){}  
	}
//	private void read(ObjectInputStream in) throws IOException,ClassNotFoundException   
//	{   
//		int l=in.readInt();   
//		int r=in.readInt();   
//		int e=in.readInt();   
//		  
//		for(int k=0;k<l;k++)   
//		{   
//			try   
//			{   
//				LineShape g=(LineShape) in.readObject();   
//				Tryframe.line.add(g);   
//			}   
//			catch(IOException m) {}   
//		}   
//		  
//		for(int k=0;k<r;k++)   
//		{   
//			try   
//			{   
//				RectShape g=(RectShape) in.readObject();   
//				SimplePanel.rect.add(g);   
//			}   
//			catch(IOException m) {}   
//			catch(ClassNotFoundException n) {}   
//		}   
//		  
//		for(int k=0;k<e;k++)   
//		{   
//			try   
//			{   
//				ElliShape g=(ElliShape) in.readObject();   
//				SimplePanel.elli.add(g);   
//			}   
//			catch(IOException m) {}   
//			   
//		}   
//	}   
	public void open(File file)
	{
		
//	    try {   
//            
//            FileInputStream fileInputStream = new FileInputStream(file);       
//            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);    
//            Object inputObject;   
//               
//            while((inputObject = objectInputStream.readObject()) != null)   
//                {   
//                    Shape shape = (Shape)(inputObject);   
////                    arrayList.add(shape);   
//                }     
//            objectInputStream.close();         
//        }    
//           
//        catch(EOFException e)   
//        {   
//        }   
//        catch (Exception e) {   
//            JOptionPane.showMessageDialog(null, "Failed To Load The File");   
//        }   
          
	}
	//����ͼƬ
	public void save()
	{
		System.out.println("save ok!");
	}
}
