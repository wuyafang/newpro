//2)	��1��+2��+����+20��
public class �׳� {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int i=0,sum=0,result=1;
		for( i=1;i<=20;i++)
		{
			result=result*i;
			sum=sum+result;
		}
		System.out.println(sum);
	}
}
