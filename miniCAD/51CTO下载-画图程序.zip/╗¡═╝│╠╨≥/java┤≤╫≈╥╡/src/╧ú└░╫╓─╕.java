
public class ϣ����ĸ {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int start=(int)'��',end=(int)'��';
            for(int i=start;i<=end;i++)
            {
            	System.out.println((char)i);
            }
	}
}
