package Phone;

public class telephone extends phone{
	public void say()
	{
		System.out.println("I can't move,but I can speak!");
	}
}
