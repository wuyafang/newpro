package Phone;

public interface move {
	 void move();
}
