package Phone;

public class mobile extends phone implements move{
	public void move()
	{
		System.out.println("I can move!");
	}
}
