package Phone;

public class nolinephone extends telephone{
	public void show()
	{
		System.out.println("I have no line,and I can speak!");
	}
}
