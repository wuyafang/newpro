package Calculater;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class Calculater {
//    private List<String> list = new ArrayList<String>();   

	public static void main(String[]args){
		//System.out.println("Hello 111Java");
		Scanner in =new Scanner(System.in);
		     
		String s;
		int left=0;
		int right=0;
		int wrong=0;
		while(!(s=in.nextLine()).equals("EOF"))
		{
	     wrong=0;
	     List<String> list=new ArrayList<String>(); 	
		// System.out.println(s.length());
		 for(int i=0;i<s.length();i++)
		  {
			char ch=s.charAt(i);
			if(Character.isDigit(ch)||(ch=='-'))
			{
				i=scanNumber(ch,i,s,list);
			}
			else if(ch=='+')
			{
				list.add(s.substring(i,i+1));
//				System.out.println(s.substring(i,i+1));
//				System.out.println(list);

				
			}
			
			else if(ch=='*')
			{
				list.add(s.substring(i,i+1));
			}
			else if(ch=='/')
			{
				list.add(s.substring(i,i+1));
			}
			else if(ch=='%')
			{
				list.add(s.substring(i,i+1));
			}
			else if(ch=='(')
			{
				list.add(s.substring(i,i+1));
				left++;
			}
			else if(ch==')')
			{
				list.add(s.substring(i,i+1));
				right++;
			}
			else if(ch==' ')
			{				
			}
			else
			{
				System.out.println("wrong input");
				wrong=1;
				break;
			}
		  }
			if(left!=right)
			{
				System.out.println("wrong input in pun");
				wrong=1;
				
			}
			for (int i = 0; i < list.size()-1; i++) 
			{
				String str1= list.get(i);
				String str2=list.get(i+1);
				int num1=0;
				int num2=0;
				
				if(str1.equals("+")||str1.equals("-")||str1.equals("*")||str1.equals("/")||str1.equals("%"))
				{
					num1=1;
				}
				else if(str1.equals("(")||str1.equals(")")||str1.equals(" "))
				{
					
				}
				else
				{
					num1=2;
				}
				if(str2.equals("+")||str2.equals("-")||str2.equals("*")||str2.equals("/")||str2.equals("%"))
				{
					num2=1;
				}
				else if(str2.equals("(")||str2.equals(")")||str2.equals(" "))
				{
					
				}
				else
				{
					num2=2;
				}
				if(num1==1&&num2==1)
				{
					System.out.println("wrong input in pun1");
					wrong=1;
				}
				if(num1==2&&num2==2)
				{
					
					System.out.println("wrong input in digit");
					wrong=1;
				}
				
			}
			if(wrong==0)
			{
			String str1= list.get(0);
			String str3= list.get(list.size()-1);
			if(str1.equals("+")||str1.equals("-")||str1.equals("*")||str1.equals("/")||str1.equals("%"))
			{
				wrong=1;
				System.out.println("wrong pun in first");
			}
			if(str3.equals("+")||str3.equals("-")||str3.equals("*")||str3.equals("/")||str3.equals("%"))
			{
				wrong=1;
				System.out.println("wrong pun in last");
			}
			}
			if(wrong==0)
			{
		   int res = calc(list);
		   System.out.println(res);
			}

		}


		}
	public static int scanNumber(char ch, int i,String s,List<String> list)
	
	{
		int j=i+1;
		if(ch=='-')
		{
			if(i>0)
			{
				if(Character.isDigit(s.charAt(i-1)))
				{
					list.add(s.substring(i,i+1));
					return i;
				}
			}
			for(j=i+1;j<s.length();j++)
			{
				if(!Character.isDigit(s.charAt(j)))
				{
					list.add(s.substring(i,j));
					
					break;
				}
				
			}
			if(i==s.length()-1)
			{
				list.add(s.substring(i,i+1));
				

			}
		}
		else
		{
			
			for(j=i+1;j<s.length();j++)
			{
				if(!Character.isDigit(s.charAt(j)))
				{
					list.add(s.substring(i,j));
					
					break;
				}
				
			}
			if(i==s.length()-1)
			{
				list.add(s.substring(i,i+1));
				
			}
		}
		if(j==s.length()&&i!=(s.length()-1))
		{
			list.add(s.substring(i,j));
		}
		
		return j-1;
	}
	

	public static int calc(List<String> list)
	{
		Stack<String> stack1 = new Stack<String>();  
		Stack<String> stack2 = new Stack<String>();   
		Stack<Integer> stack3 = new Stack<Integer>();   

		int res=0;
		 for (String string : list) 
		 {
			 if(string.equals("+")||string.equals("-"))
			 {
				 //System.out.println(stack1);
				 if(stack2.empty())
				 {
					 stack2.push(string);
				 }
				 else if(stack2.peek().equals("("))
				 {
					 stack2.push(string);
				 }
				 else
				 {
					while(!(stack2.empty()||stack2.peek().equals("(")) )
					{
						String sss=stack2.pop();
						stack1.push(sss);
						
					}
					stack2.push(string);
				 }
				 
			 }
			 else if(string.equals("*")||string.equals("/")||string.equals("%"))
			 {
				 if(stack2.empty())
				 {
					 stack2.push(string);
				 }
				 else if(stack2.peek().equals("+")||stack2.peek().equals("-")||(stack2.peek().equals("(")))
				 {
					 stack2.push(string);
				 }
				 else
				 {
					while(!(stack2.empty()||stack2.peek().equals("+")||stack2.peek().equals("-")||stack2.peek().equals("(")) )
					{
						String sss=stack2.pop();
						stack1.push(sss);
						

					}
					stack2.push(string);
				 }
			 }
			 else if(string.equals("("))
			 {

				 stack2.push(string);
			 }
			 else if(string.equals(")"))
			 {
				 while(!stack2.peek().equals("("))
				 {
					 String sr=stack2.pop();
					 stack1.push(sr);
				 }
				 stack2.pop();
				 
			 }
			 else 
			 {
				 stack1.push(string);
			 }
			          
		 }
		 while(!stack2.empty())
		 {
			 String ss=stack2.pop();
			 stack1.push(ss);
		 }
		 //System.out.println(stack1);

		 while(!stack1.empty())
		 {
			 String ss=stack1.pop();
			 stack2.push(ss);
		 }
		 //System.out.println(stack2);

		 while(!stack2.empty())
		 {
			 String ss=stack2.pop();
			 if(ss.equals("+"))
			 {
				int a=stack3.pop() ;
				int b =stack3.pop();
				a =a+b;
				stack3.push(a);
				//System.out.println(stack3);
			 }
			 else if(ss.equals("-"))
			 {
				 
				 int a=stack3.pop() ;
				 int b =stack3.pop();
					a =b-a;
					stack3.push(a);
			 }
			 else if(ss.equals("*"))
			 {
				 int a=stack3.pop() ;
				 int b =stack3.pop();
					a =a*b;
					stack3.push(a);
			 }
			 else if(ss.equals("/"))
			 {
				 int a=stack3.pop() ;
					//System.out.println(a);

					int b =stack3.pop();
					a =b/a;
					//System.out.println(a);
					stack3.push(a);
			 }
			 else if(ss.equals("%"))
			 {
				 int a=stack3.pop() ;
					int b =stack3.pop();
					a =b%a;
					stack3.push(a);
			 }
			 else
			 {
				 int num=Integer.parseInt(ss);
				 stack3.push(num);
			 }
		 }
		 res= stack3.pop();
		 

		
		return res;
	}
}
