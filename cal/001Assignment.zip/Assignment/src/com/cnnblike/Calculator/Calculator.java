package com.cnnblike.Calculator;
import java.util.*;
import parsii.eval.*;
import parsii.tokenizer.*;

/**
 * Created by cnnblike_Mac on 14/11/11.
 */
public class Calculator {
    public static void main(String[] args) throws ParseException{
        Scanner in=new Scanner(System.in);
        String ExprString = in.next();
        while(!(ExprString.equals("EOF"))) {
            Scope scope = Scope.create();
            Expression expr = Parser.parse(ExprString, scope);
            System.out.println(expr.evaluate());
            ExprString = in.next();
        }
    }
}
