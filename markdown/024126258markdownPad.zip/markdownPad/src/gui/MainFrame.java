package gui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.io.*;

import console.MarkdownFilter;
import gui.ViewPane;
import gui.EditPane;
import console.FileOperation;

public class MainFrame implements ActionListener{
	private JFrame mkdown;
	private File file;
	private FileOperation fop = new FileOperation();
	private EditPane editPane;
	private ViewPane viewPane;
	
	public MainFrame(){
		mkdown = new JFrame();
		JMenuBar  menubar = new JMenuBar();
		mkdown.setJMenuBar(menubar);
		//set menu bar
		JMenu fileMenu =  new JMenu("File");
		menubar.add(fileMenu);
		JMenuItem openItem = new JMenuItem("open");
		openItem.addActionListener(this);
		fileMenu.add(openItem);
		JMenuItem saveItem = new JMenuItem("save");
		saveItem.addActionListener(this);
		fileMenu.add(saveItem);
		JMenuItem quitItem = new JMenuItem("quit");
		quitItem.addActionListener(this);
		fileMenu.add(quitItem);
		
		//set the edit and view pane
		editPane = new EditPane();
		viewPane = new ViewPane();
		editPane.addObserver(viewPane);
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,editPane.get(),viewPane.get());
		
		//set the mainframe
		mkdown.add(splitPane);  
		mkdown.setSize(1024, 640);
		mkdown.setTitle("MarkDown Pad");
		mkdown.setVisible(true);
		splitPane.setDividerLocation(0.5);
		

	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int retval;
		String command = e.getActionCommand();
		if(command.equals("open")) {
			//create file open dialog 
			JFileChooser openDialog = new JFileChooser();
			openDialog.setFileSelectionMode(JFileChooser.FILES_ONLY); //����ֻ�ܴ��ļ�
			//�����úõ��ļ����������ӵ��ļ�ѡ��������
			MarkdownFilter markdownFilter = new MarkdownFilter();
			openDialog.addChoosableFileFilter(markdownFilter);
			openDialog.setFileFilter(markdownFilter);
			retval = openDialog.showDialog(null, "open file");
			if (retval == JFileChooser.APPROVE_OPTION) {
				file = openDialog.getSelectedFile();
				String content = "";
				try {
					content = fop.readFile(file);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				editPane.replaceWith(content);
				
			}	
		}else if (command.equals("save")){
			JFileChooser saveDialog = new JFileChooser();
			saveDialog.setDialogType(JFileChooser.SAVE_DIALOG);  //���öԻ���ģʽΪ����
			saveDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
			MarkdownFilter csvFileFilter = new MarkdownFilter();
			saveDialog.addChoosableFileFilter(csvFileFilter);
			saveDialog.setFileFilter(csvFileFilter);
			saveDialog.setCurrentDirectory(file); //����Ĭ�ϱ���·��
			retval = saveDialog.showDialog(null, "save file");
			if(retval == JFileChooser.APPROVE_OPTION){
				File saveFile = saveDialog.getSelectedFile();
				try {
					fop.writeFile(saveFile, editPane.getContent());
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		}else if (command.equals("quit")){
			
		}
	}

}
