package console;

import java.io.*;

public class FileOperation {
	public String readFile(File f)throws IOException{
		String content = "";
		String temp ="";
		BufferedReader bf = new BufferedReader(new FileReader(f));
		
		while(temp!=null){
			temp = bf.readLine();
			if(temp == null){
				break;
			}
			content = content+temp+"\n";
		}
		
		bf.close();
		return content;
	}
	
	public void writeFile(File f,String text) throws IOException{
		FileWriter fw = new FileWriter(f);
		fw.write(text);
		fw.flush();
		fw.close();
	}
}
