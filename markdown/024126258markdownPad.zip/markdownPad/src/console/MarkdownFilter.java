package console;

import java.io.File;

public class MarkdownFilter extends javax.swing.filechooser.FileFilter{

	@Override
	public boolean accept(File f) {
		// TODO Auto-generated method stub
		String[] okFileExtensions =  new String[] {"txt", "md", "markdown","mkdown"};
	    
		for (String extension : okFileExtensions)
	    {
		  if (f.isDirectory()){
			  return true;
		  }else if (f.getName().toLowerCase().endsWith(extension))
	      {
	        return true;
	      }
	    }
	    return false;

		
	}
		
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Markdown Files��*.txt, *.md, *.markdown, *.mkdown)";
	}
	
}
