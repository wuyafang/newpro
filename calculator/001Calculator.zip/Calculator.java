
import java.util.*;
import java.io.*;

class Calculator {

    public boolean isOperator(String s) {
        return s.equals("+")
            || s.equals("-")
            || s.equals("*")
            || s.equals("/")
            || s.equals("%");
    }

    Queue<String> tokenize(String expression) throws Exception {
    	Queue<String> q = new ArrayDeque<String>();

        ByteArrayInputStream is = new ByteArrayInputStream(expression.getBytes());
        char nextChar;
        int inputChar;
        StringBuffer curElement = null;
        boolean state = false;

        while ((inputChar = is.read()) != -1) {
            nextChar = (char)inputChar;
            if (state) {
                if (Character.isDigit(nextChar)) {
                    curElement.append(nextChar);
                    continue;
                }
                else {
                    state = false;
                    q.add(curElement.toString());
                    curElement = null;
                }
            }

            if (Character.isWhitespace(nextChar)) {
                continue;
            }
            else if (Character.isDigit(nextChar)) {
                assert(!state);
                state = true;
                curElement = new StringBuffer();
                curElement.append(nextChar);
            }
            else if (isOperator(String.valueOf(nextChar))
            			|| nextChar == '('
            			|| nextChar == ')') {
                q.add(String.valueOf(nextChar));
            }
            else {
                throw new Exception("Element illegal: "+String.valueOf(nextChar));
            }
        }

        if (curElement != null) {
            q.add(curElement.toString());
        }

//        Queue<String> tmp1 = new ArrayDeque<String>(q);
//        while (tmp1.size() > 0) {
//        	System.out.println(tmp1.peek());
//        	tmp1.remove();
//        }
        
        Queue<String>elementQueue = new ArrayDeque<String>();
        String nowReading = null;
        String previouslyToken = null;
        while (!q.isEmpty()) {
        	previouslyToken = nowReading;
        	nowReading = q.peek();
        	q.remove();
        	if (nowReading.equals("-")
        			&& !q.isEmpty()
        			&& !isOperator(q.peek())
        			&& (elementQueue.isEmpty()
        					|| isOperator(previouslyToken)
       						|| previouslyToken.equals("("))) {
        			elementQueue.add(nowReading+q.peek());
        			q.remove();
        	}
        	else {
        		elementQueue.add(nowReading);
        	}
        }

//        Queue<String> tmp = new ArrayDeque<String>(elementQueue);
//        while (tmp.size() > 0) {
//        	System.out.println(tmp.peek());
//        	tmp.remove();
//        }
        
        return elementQueue;
    }

    int input(String expression) throws Exception{
        Parser parser = new Parser();
        ParseNode node = parser.parse(tokenize(expression));
        return node.getValue();
    }

    private static abstract class ParseNode {
        String token;

        public ParseNode(String token) {
            this.token = token;
        }

        public String toString() {
            return token;
        }

        public abstract int getValue();
    }

    private static class OperatorNode extends ParseNode {
        List<ParseNode> children = new ArrayList<ParseNode>();

        private OperatorNode(String token) {
            super(token);
        }

        public static OperatorNode withChildren(String token, ParseNode left, ParseNode right) {
            OperatorNode node = new OperatorNode(token);
            node.children.add(left);
            node.children.add(right);
            return node;
        }

        public int getValue() {
            if (token.equals("+"))
                return children.get(0).getValue() + children.get(1).getValue();
            if (token.equals("-"))
                return children.get(0).getValue() - children.get(1).getValue();
            if (token.equals("*"))
                return children.get(0).getValue() * children.get(1).getValue();
            if (token.equals("/"))
                return children.get(0).getValue() / children.get(1).getValue();
            if (token.equals("%"))
                return children.get(0).getValue() % children.get(1).getValue();
            return 0;
        }
    }

    private static class OperandNode extends ParseNode {

        public OperandNode(String token) {
            super(token);
        }

        public int getValue() {
            return Integer.parseInt(token);
        }
    }

    private class Parser {
        private String nowReading;
        private String previouslyToken;
        private Queue<String> q;

        private boolean isOperand(String s) {
    		return !isOperator(s) && !s.equals("(") && !s.equals(")");
        }

        private boolean startsExpr0(String token) {
            return startsExpr1(token);
        }
        private boolean startsExpr1(String token) {
            return startsExpr2(token);
        }
        private boolean startsExpr2(String token) {
            return token.equals("(") || isOperand(token);
        }

        private ParseNode parseExpr() throws Exception {
        	readToken();
            return parseExpr0();
        }
        private ParseNode parseExpr0() throws Exception {
            if (!startsExpr0(nowReading)) {
                error("Expr0 "+nowReading);
            }

            ParseNode left = parseExpr1();
            while (nowReading != null && (nowReading.equals("+") || nowReading.equals("-"))) {
                String operator = nowReading;
                readToken();
                ParseNode right = parseExpr1();
                left = OperatorNode.withChildren(operator, left, right);
            }
            return left;
        }
        private ParseNode parseExpr1() throws Exception {
            if (!startsExpr1(nowReading)) {
                error("Expr1 "+nowReading);
            }

            ParseNode left = parseExpr2();
            while (nowReading != null && (nowReading.equals("*") || nowReading.equals("/") || nowReading.equals("%"))) {
                String operator = nowReading;
                readToken();
                ParseNode right = parseExpr2();
                left = OperatorNode.withChildren(operator, left, right);
            }
            return left;
        }
        private ParseNode parseExpr2() throws Exception {
            if (!startsExpr2(nowReading)) {
                error("Expr2 "+nowReading);
            }

            if (nowReading != null) {
            	if (nowReading.equals("(")) {
	                expect("(");
	                ParseNode node = parseExpr0();
	                expect(")");
	                return node;       
	            }
	            else {
	            	return parseNumber();
	            }
            }
            else {
                error("null "+nowReading);
            }
            return null;
        }
        
        private ParseNode parseNumber() throws Exception {
            readToken();
            return new OperandNode(previouslyToken);
        }

        public ParseNode parse(Queue<String> elementQueue) throws Exception {
            q = elementQueue;
            return parseExpr();
        }

        private void readToken() throws Exception {
            previouslyToken = nowReading;
            nowReading = q.peek();
            if (nowReading != null) {
            	q.remove();
            }
        }

        private void expect(String token) throws Exception {
            if (nowReading ==null || !nowReading.equals(token)) {
                error("expect "+token);
            }
            readToken();
        }

        private void error(String s) throws Exception {
            throw new Exception("Expression illegal: "+s);
        }
    }


    public static void main(String args[]) throws IOException {
        Calculator calculator = new Calculator();

        // Valid cases
//        String expression = "3 + 5 * 6";
//        String expression = "3 + (5 % 6)";
//        String expression = "3 % 5 +(1323-1203/424) - 6*32";
//        String expression = "123 * ((24 + 43 * 64 - (83 + 47)) + 19)";
//        String expression = "123 * ((24 + 43 * 6 % 4 - (83 + 47)) + 19)";
        
        // Invalid cases
//        String expression = "(-123 ++ -23)";
//        String expression = "123 * ((24 + 43 * 6 % 4 - (83 + 47)) + 19)";
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Input expression: ");
        String expression = br.readLine();
        
        try {
            int result = calculator.input(expression);
            System.out.println("Result: " + result);
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}